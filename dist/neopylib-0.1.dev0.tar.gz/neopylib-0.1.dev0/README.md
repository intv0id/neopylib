neopylib
===

A pythonic neo4j queries generator
---

This project is currently a proof of concept.

[Check for examples here!](https://mybinder.org/v2/gh/intv0id/neopylib/master?filepath=examples.ipynb)